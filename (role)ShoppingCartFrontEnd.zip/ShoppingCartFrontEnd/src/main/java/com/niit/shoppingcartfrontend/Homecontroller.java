package com.niit.shoppingcartfrontend;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Homecontroller 
{
	
	@RequestMapping("/")
	public String gotoindex(Model model){
		model.addAttribute("carousel", "true");
		
		return"index";
	}
	

	@RequestMapping("/home")
	public String gotohome(Model model){
		model.addAttribute("carousel", "true");
		
		return"index";
	}
	
	
	@RequestMapping("/trail")
	public String trail(){
		return("trail");
	}

	@RequestMapping("/login")
	public String gotologin(Model model){
		model.addAttribute("userClickedlogin", "true");
		return"index";
	}
	
@RequestMapping("/registeration")
public String gotoregisteration(Model model){
	model.addAttribute("userClickedregisteration","true"); 
	return "index";
	}

@RequestMapping("/validate")
public String gotovalidate(@RequestParam(name="email")String emid,@RequestParam(name="password")String asd, Model model)
{
	if(emid.equals("sumzu")&& asd.equals("niit"))
	{
		model.addAttribute("sucessMessage", "you sucessfully logged in");
		model.addAttribute("carousel", "true");
		return "index";	
	}
	else
	{
		model.addAttribute("errorMessage","invalid user id or password.please try again later");
		return "index";
	}
}
@RequestMapping
public String gotoproduct()
  {
	return("product");
  }


}
