package com.niit.backend.model;

public class User {

}
