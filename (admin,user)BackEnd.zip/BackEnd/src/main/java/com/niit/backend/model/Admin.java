package com.niit.backend.model;

public class Admin {
	
	public String admin_id;
	public String admin_name;
	public String admin_password;
	
	

}
