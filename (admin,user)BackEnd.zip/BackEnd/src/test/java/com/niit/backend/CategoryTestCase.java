package com.niit.backend;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.CategoryDAO;
import com.niit.backend.dao.SupplierDAO;
import com.niit.backend.model.Category;
import com.niit.backend.model.Supplier;

public class CategoryTestCase {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Category category;
	
	@Autowired
	static CategoryDAO categoryDao;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 categoryDao=  (CategoryDAO) context.getBean("categoryDAO");
		 category=  (Category) context.getBean("category");
			 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createSupplierTestCase()
	 {  
		category.setCat_id("cat05");
		category.setCat_description("outdoor games");
		category.setCat_name("karatake");
		
		
		Boolean status= categoryDao.save(category);
		Assert.assertEquals("create", true, status);
		
		 }
	
	@Test
	public void updateSupplierTestCase()
	 {  
		category.setCat_id("cat01");
		category.setCat_description("armature");
		category.setCat_name("Rugby");
		
		
		Boolean status= categoryDao.update(category);
		Assert.assertEquals("create", true, status);
		
		 }

	@Test
	public void deleteSupplierTestCase()
	 {  
		category.setCat_id("sup10");
		
		
		Boolean status= categoryDao.delete(category);
		Assert.assertEquals("create", true, status);
		
		 }


}
