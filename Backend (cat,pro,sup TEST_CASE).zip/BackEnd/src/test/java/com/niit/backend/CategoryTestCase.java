package com.niit.backend;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.CategoryDAO;
import com.niit.backend.model.Category;

public class CategoryTestCase

{


	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Category category;
	
	@Autowired
	static CategoryDAO categoryDAO;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 categoryDAO= (CategoryDAO) context.getBean("categoryDAO");
		 category= (Category) context.getBean("category");
		 
		 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createCategoryTestCase()
	 {  
		category.setCat_id("sprt01");
		category.setCat_description("armature sports");
		category.setCat_name("kick-boxing");
		
		
		Boolean status= categoryDAO.save(category);
		Assert.assertEquals("create", true, status);
		
		 }
	
	@Test
	public void updateCategoryTestCase()
	 {  
		category.setCat_id("sprt01");
		category.setCat_description("armature sports ");
		category.setCat_name("kick-boxing vs boxing");
		
		
		Boolean status= categoryDAO.save(category);
		Assert.assertEquals("create testcase", true, status);
		
		 }
	@Test
	public void deleteCategoryTestCase()
	 {  
		category.setCat_id("sprt01");
		
		
		Boolean status= categoryDAO.delete(category);
		Assert.assertEquals("create testcase", true, status);
		
		 }

}
