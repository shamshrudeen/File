package com.niit.backend.dao;

import java.util.List;

import com.niit.backend.model.Category;



public interface CategoryDAO 
  {
	
		   public Boolean save(Category category);
		   public Boolean update(Category category);
		   public Boolean delete(Category category);
		   
		   public Category get(String id);
		   public List<Category> list();
		 

	
	

 }
