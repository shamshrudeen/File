package com.niit.backend.dao;

import java.util.List;

import com.niit.backend.model.Supplier;

public interface SupplierDAO 
 {
   public Boolean save(Supplier supplier);
   public Boolean update(Supplier supplier);
   public Boolean delete(Supplier supplier);
   
   public Supplier get(String id);
   public List<Supplier> list();
 }
