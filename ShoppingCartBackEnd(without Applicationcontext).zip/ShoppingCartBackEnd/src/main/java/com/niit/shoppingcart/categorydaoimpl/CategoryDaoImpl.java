package com.niit.shoppingcart.categorydaoimpl;



import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.niit.shoppingcartbackend.categorydao.CategoryDao;
import com.niit.shoppingcartbackend.categorymodel.Category;




public class CategoryDaoImpl implements CategoryDao {

	 
	SessionFactory sessionFactory;
	public CategoryDaoImpl (SessionFactory sessionFactory){
	this.sessionFactory=sessionFactory;
	}
	
	
	public Boolean create(Category category) {
try {
	sessionFactory.getCurrentSession().save(category);
	return true;
} catch (HibernateException e) {
	
	e.printStackTrace();
}
		
		return false;
	}

	public Boolean update(Category category) {
		try {
			sessionFactory.getCurrentSession().update(category);
			return true;
		} catch (HibernateException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	public Boolean delete(Category category) {
		try {
			sessionFactory.getCurrentSession().delete(category);
			return true;
		} catch (HibernateException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	public Category get(String id) {
		
		return(Category) sessionFactory.getCurrentSession().get(Category.class,id);
		
	}

	public List<Category> list() {
		String hql="from Category";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

	
}
