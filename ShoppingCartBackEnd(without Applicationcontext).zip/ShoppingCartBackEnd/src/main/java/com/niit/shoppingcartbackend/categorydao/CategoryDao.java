package com.niit.shoppingcartbackend.categorydao;

import java.util.List;

import com.niit.shoppingcartbackend.categorymodel.Category;

public interface CategoryDao  {
	
	public Boolean create(Category category);
	
	public Boolean update(Category category);
	
	public Boolean delete(Category category);
	
	public Category get(String id);
	public List<Category> list();

}
