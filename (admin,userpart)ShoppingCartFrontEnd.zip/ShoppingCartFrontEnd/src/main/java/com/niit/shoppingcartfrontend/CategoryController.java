package com.niit.shoppingcartfrontend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.backend.dao.CategoryDAO;
import com.niit.backend.model.Category;

@Controller    
public class CategoryController{

	
	static AnnotationConfigApplicationContext ac;
	static private CategoryDAO categoryDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		categoryDAO=(CategoryDAO) ac.getBean("CategoryDAO");
		
	}

	@ModelAttribute("category")
	public Category getcategory(){
		return new Category();
	}
	
	@RequestMapping(value="/managecategory",method= RequestMethod.POST)
	public String catadd(@ModelAttribute("category")Category ca ){
	categoryDAO.save(ca);
		return "redirect:/category";
	}
	
}

