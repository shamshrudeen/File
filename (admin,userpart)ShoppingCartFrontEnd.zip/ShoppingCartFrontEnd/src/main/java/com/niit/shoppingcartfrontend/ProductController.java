/*package com.niit.shoppingcartfrontend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.backend.dao.ProductDAO;
import com.niit.backend.model.Product;

public class ProductController 
{
	@Autowired
	ProductDAO productDAO;
	
	@ModelAttribute("proobject")
	public Product getProduct(){
		return new Product();
		}
	
	@RequestMapping(value="/manageproduct",params="add",method=RequestMethod.POST)
	public String prodd(@ModelAttribute("proobject")Product pa,Model model ){
		productDAO.save(pa);
		
		return "index";
	}
	

	@RequestMapping(value="/manageproduct",params="update",method=RequestMethod.POST)
	public String proupdate(@ModelAttribute("proobject")Product pa,Model model ){
		productDAO.update(pa);
		return "index";
	}
	
	@RequestMapping(value="/manageproduct",params="delete",method=RequestMethod.POST)
	public String proupdelete(@ModelAttribute("proobject")Product pa,Model model ){
		productDAO.delete(pa);
		return "index";
	}
	

}
*/
