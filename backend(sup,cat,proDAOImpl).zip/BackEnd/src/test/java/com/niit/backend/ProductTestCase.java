package com.niit.backend;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.ProductDAO;
import com.niit.backend.model.Product;

public class ProductTestCase {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Product product;
	
	@Autowired
	static ProductDAO productDAO;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 productDAO= (ProductDAO) context.getBean("productDAO");
		 product= (Product) context.getBean("product");
		 
		 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createSupplierTestCase()
	 {  
		product.setPro_id("pro01");
		product.setPro_name("Boxing bag");
		product.setPro_description("150lbs punching bag");
		product.setPro_price(50.00);
		
		Boolean status= productDAO.save(product);
		Assert.assertEquals("create", true, status);
		
		 }


	
}
