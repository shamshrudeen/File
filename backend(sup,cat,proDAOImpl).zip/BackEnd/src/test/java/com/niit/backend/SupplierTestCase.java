package com.niit.backend;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.SupplierDAO;
import com.niit.backend.model.Supplier;



public class SupplierTestCase 
{

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Supplier supplier;
	
	@Autowired
	static SupplierDAO supplierDAO;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 supplierDAO= (SupplierDAO) context.getBean("supplierDAO");
		 supplier= (Supplier) context.getBean("supplier");
		 
		 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createSupplierTestCase()
	 {  
		supplier.setId("sup55");
		supplier.setAddress("chennai");
		supplier.setName("saha");
		
		
		Boolean status= supplierDAO.save(supplier);
		Assert.assertEquals("create", true, status);
		
		 }
	
	@Test
	public void updateSupplierTestCase()
	 {  
		supplier.setId("sup11");
		supplier.setAddress("poonamalle");
		supplier.setName(" poonmalle");
		
		
		Boolean status= supplierDAO.save(supplier);
		Assert.assertEquals("create", true, status);
		
		 }

	@Test
	public void deleteSupplierTestCase()
	 {  
		supplier.setId("sup56");
		supplier.setAddress("chennai");
		supplier.setName("selva");
		
		
		Boolean status= supplierDAO.save(supplier);
		Assert.assertEquals("create", true, status);
		
		 }
}
