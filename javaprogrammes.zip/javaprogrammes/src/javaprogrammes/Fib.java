package javaprogrammes;

public class Fib 
{
	public static void main (String args[])
	{
		int x=0,y=1,z;
		System.out.print(" "+x);
		System.out.print(" "+y);
		
	
	for(int i=2;i<10;i++)
		
	{
	  z=x+y;
	 System.out.print(" "+z);
	 
	x=y;
	y=z;
	}

}
}
