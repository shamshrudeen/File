package javaprogrammes;

public class Reversenumbers 
{
    public static void main(String args[])
 {
	 int a=123;
	 
	int n=a, r=0;
	 while(a!=0)
		 {
		     r=r*10;
	         r=r+a%10;
	         a=a/10;
	         System.out.println("r at every loop is"+r);
	         System.out.println("a at every loop is"+a);
		  }
	         System.out.println("rever number is"+r);
	 if(n==r)
	 { 
		 System.out.println("its palindrome") ;
	 }
	 else
	 {
		 System.out.println("Its not palindrome");
	 }         
 }
}
