package javaprogrammes;

import java.util.Scanner;

public class Pyramidnumber 
{
	public static void main(String args[])
	{
      
      Scanner d=new Scanner(System.in);
      System.out.println("enter the rows in which the pyramid should be display");
      int a=d.nextInt();
      
      for(int i=1;i<=a;i++)
       {
	     for(int j=a-i;j>0;j--)
	     {
	    	 System.out.print("*"); 
	     }
	      for (int k=1;k<=i;k++)
	      {
	    	  System.out.print(" "+k);
	      }
	      System.out.println();
       }


	}
}
