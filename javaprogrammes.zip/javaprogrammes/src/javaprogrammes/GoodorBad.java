package javaprogrammes;

public class GoodorBad 
{
	
    public static void main (String args[])
  {
    	
    	int a[]={97,78,-41,-42,99,-87};
 	   int b, c = 0;

 	
 	   b=a[0];
 	   for(int j=0;j<=5;j++)
 	   {
 	     while(b<a[j])
 	       {
 	    
c=a[j];
 	       }
 	       
 	   }
 	     
 	
 	
 	 System.out.println(""+c);
  }
}
