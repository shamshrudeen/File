package javaprogrammes;

public class Sumequaltofive {
	

}
