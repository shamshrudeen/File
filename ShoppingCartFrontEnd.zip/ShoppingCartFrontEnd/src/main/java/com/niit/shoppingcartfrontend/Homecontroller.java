package com.niit.shoppingcartfrontend;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Homecontroller 
{
	
	@RequestMapping("/")
	public String gotoindex(){
		return"index";
	}
	

	@RequestMapping("/login")
	public String gotologin(Model model){
		model.addAttribute("userClickedlogin", "true");
		return"index";
	}
	
@RequestMapping("/registeration")
public String gotoregisteration(Model model){
	model.addAttribute("userClickedregisteration","true"); 
	return "index";
	}

@RequestMapping("/validate")
public String gotovalidate(@RequestParam(name="userID")String id,@RequestParam(name="password")String asd, Model model)
{
	if(id.equals("niit")&& asd.equals("niit"))
	{
		model.addAttribute("sucessMessage", "you sucessfully logged in");
		return "brand";	
	}
	else
	{
		model.addAttribute("errorMessage","User id & password mistach. please try again");
		return "login";
	}
}



}
