package com.niit.backend;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.UserDAO;
import com.niit.backend.model.User;

public class UserTestCase {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
@Autowired
	static User User;
	
	@Autowired
	static UserDAO UserDao;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 UserDao=  (UserDAO) context.getBean("UserDAO");
		 User=  (User) context.getBean("user");
			 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createUserTestCase()
	 {  
		
		User.setUser_id("pro02");
		User.setUser_password("hello");
		User.setRole("user");
		
		
		Boolean status= UserDao.save(User);
		Assert.assertEquals("create", true, status);
		
	
}
}