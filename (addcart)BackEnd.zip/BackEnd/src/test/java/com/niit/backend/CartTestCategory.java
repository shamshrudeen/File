/*package com.niit.backend;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.AddcartDAO;
import com.niit.backend.model.Addcart;

public class CartTestCategory {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Addcart addcart;
	
	@Autowired
	static AddcartDAO cartDao;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 cartDao=  (AddcartDAO) context.getBean("AddcartDAO");
		 addcart=   (Addcart) context.getBean("addcart");
			 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createCategoryTestCase()
	 {  
		addcart.setUser_id("df");
		addcart.setPro_id("sd");
		addcart.setPro_price(200.00);
       addcart.setSrno("ds");
		addcart.setUserid_date("dff");
		
		
		Boolean status= cartDao.save(addcart);
		Assert.assertEquals("create", true, status);
		
		 }
	
/*	@Test
	public void updateCategoryTestCase()
	 {  
		cart.setUser_id("");
		cart.setPro_id("");
		cart.setPro_price(200.00);

		
		
		Boolean status= cartDao.update(cart);
		Assert.assertEquals("create", true, status);
		
		 }

	//@Test
	public void deleteCategoryTestCase()
	 { 
		cart.setUser_id("");
		cart.setPro_id("");
		cart.setPro_price(200.00);

		
		Boolean status= cartDao.delete(cart);
		Assert.assertEquals("create", true, status);
		
}		 }

*/
	

