package com.niit.backend;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.backend.dao.SupplierDAO;
import com.niit.backend.model.Supplier;



public class SupplierTestCase 
{

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Supplier supplier;
	
	@Autowired
	static SupplierDAO supplierDAO;
	
	@BeforeClass
	public static void init()
	  {
		 context=new AnnotationConfigApplicationContext();
		 context.scan("com.niit");
		 context.refresh();
		 
		 supplierDAO= (SupplierDAO) context.getBean("supplierDAO");
		 supplier= (Supplier) context.getBean("supplier");
		 
		 System.out.println("objects are created");
	  }
	
	
	@Test
	public void createSupplierTestCase()
	 {  
		supplier.setId("sup15");
		supplier.setAddress("mangadu");
		supplier.setName(" suresh noufel");
		
		
		Boolean status= supplierDAO.save(supplier);
		Assert.assertEquals("create", true, status);
		
		 }
	
	@Test
	public void updateSupplierTestCase()
	 {  
		supplier.setId("sup04");
		supplier.setAddress("guindy");
		supplier.setName("arthi");
		
		
		Boolean status= supplierDAO.update(supplier);
		Assert.assertEquals("create", true, status);
		
		 }

	@Test
	public void deleteSupplierTestCase()
	 {  
		supplier.setId("sup01");
		
		
		Boolean status= supplierDAO.delete(supplier);
		Assert.assertEquals("create", true, status);
		
		 }
}
