/*package com.niit.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.backend.dao.OrderDAO;
import com.niit.backend.model.Order;

@Repository("orderDAO")
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	SessionFactory sessionFactory;
	public OrderDAOImpl(){};
	public OrderDAOImpl(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;
	}
	
	@Transactional
	public Boolean save(Order order) {
		try {
			sessionFactory.getCurrentSession().save(order);
			return true;
		} catch (HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
	
	}
	@Transactional
	public Boolean update(Order order) {
		try {
			sessionFactory.getCurrentSession().update(order);
			return true;
		} catch (HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
	}
	@Transactional
	public Boolean delete(Order order) {
		
		try {
			sessionFactory.getCurrentSession().delete(order);
			return true;
		} catch (HibernateException e) {
			
			e.printStackTrace();
			return false;
		}
	}
	@Transactional
	public Order get(String id) {
	return(Order)sessionFactory.getCurrentSession().get(Order.class,id);

	}
	@Transactional
	public List<Order> list() {
		String hql="from order";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

}
*/