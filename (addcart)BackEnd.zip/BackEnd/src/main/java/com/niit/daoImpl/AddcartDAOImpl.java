package com.niit.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.backend.dao.AddcartDAO;
import com.niit.backend.model.Addcart;


@Repository("addcartDAO")
public class AddcartDAOImpl implements AddcartDAO {

	@Autowired
	SessionFactory sessionFactory;
	public AddcartDAOImpl(){};
	public AddcartDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	
	
	@Transactional
	public Boolean save(Addcart addcart) {
		
		
		try 
		{
			sessionFactory.getCurrentSession().save(addcart);
		return true;
		} 
		
		catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
@Transactional
	public List<Addcart> list() {
		String hql="from Addcart";
	Query query= sessionFactory.getCurrentSession().createQuery(hql);
	 return query.list();
	}
@Transactional
	public Addcart get(String Id) {
		
		return(Addcart)sessionFactory.getCurrentSession().get(Addcart.class,Id);
	}
	

}
