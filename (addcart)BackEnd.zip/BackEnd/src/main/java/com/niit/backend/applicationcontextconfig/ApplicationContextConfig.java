package com.niit.backend.applicationcontextconfig;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.backend.dao.AddcartDAO;
import com.niit.backend.dao.CategoryDAO;
import com.niit.backend.dao.ProductDAO;
import com.niit.backend.dao.SupplierDAO;
import com.niit.backend.dao.UserDAO;
import com.niit.backend.model.Addcart;
import com.niit.backend.model.Category;
import com.niit.backend.model.Product;
import com.niit.backend.model.Supplier;
import com.niit.backend.model.User;
import com.niit.daoImpl.AddcartDAOImpl;
import com.niit.daoImpl.CategoryDAOImpl;
import com.niit.daoImpl.ProductDAOImpl;
import com.niit.daoImpl.SupplierDAOImpl;
import com.niit.daoImpl.UserDAOImpl;

@Configuration
@ComponentScan("com.niit")
@EnableTransactionManagement

public class ApplicationContextConfig 
{

	@Bean(name="dataSource")
	public DataSource getH2DataSource()
	   {
	     DriverManagerDataSource dataSource=new DriverManagerDataSource();
	     dataSource.setUrl("jdbc:h2:tcp://localhost/~/ecommerce1");
	     dataSource.setDriverClassName("org.h2.Driver"); 
	
	     dataSource.setUsername("sa");
	     dataSource.setPassword("");
	     return dataSource;
	   }
	private Properties getHibernateProperties()
	   {
		 Properties properties=new Properties();
	     properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		 return properties;	
	   }
	
	@Autowired
	@Bean(name="sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource)
	  {
         LocalSessionFactoryBuilder sessionBuilder=new LocalSessionFactoryBuilder(dataSource);
         sessionBuilder.addProperties(getHibernateProperties());
	     sessionBuilder.addAnnotatedClass(Supplier.class);
	     sessionBuilder.addAnnotatedClass(Product.class);
	     sessionBuilder.addAnnotatedClass(Category.class);
	     sessionBuilder.addAnnotatedClass(User.class);
	    sessionBuilder.addAnnotatedClass(Addcart.class);
	    
	     
         return sessionBuilder.buildSessionFactory();
	  }
   @Autowired
   @Bean(name="transactionManager")
   public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory)
     {
	    HibernateTransactionManager transactionManager=new HibernateTransactionManager(sessionFactory);
	    return transactionManager;
     }
   
   
@Autowired
@Bean(name="CategoryDAO")
public CategoryDAO getcatDAO(){
	
	return new CategoryDAOImpl();
} 


@Autowired
@Bean(name="ProductDAO")
public ProductDAO getproDAO(){
	
	return new ProductDAOImpl();

}

@Autowired
@Bean(name="SupplierDAO")
public SupplierDAO getsupDAO(){
	
	return new SupplierDAOImpl();

}


@Autowired
@Bean(name="UserDAO")
public UserDAO getuserDAO(){
	
	return new UserDAOImpl();

}


@Autowired
@Bean(name="AddcartDAO")
public AddcartDAO getaddcartDAO(){
	
	return new AddcartDAOImpl();

}


}