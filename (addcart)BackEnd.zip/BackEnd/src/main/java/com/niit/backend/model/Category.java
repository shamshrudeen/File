package com.niit.backend.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Category 
{
	@Id
public String cat_id;
	
public String cat_name;
public String Cat_description;

public String getCat_id() {
	return cat_id;
}
public void setCat_id(String cat_id) {
	this.cat_id = cat_id;
}
public String getCat_name() {
	return cat_name;
}
public void setCat_name(String cat_name) {
	this.cat_name = cat_name;
}
public String getCat_description() {
	return Cat_description;
}
public void setCat_description(String cat_description) {
	Cat_description = cat_description;
}


}
