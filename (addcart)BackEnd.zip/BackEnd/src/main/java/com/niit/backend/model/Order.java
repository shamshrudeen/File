/*package com.niit.backend.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Order {
	
	public String bill_add;

	public String getBill_add() {
		return bill_add;
	}

	public void setBill_add(String bill_add) {
		this.bill_add = bill_add;
	}
	

}
*/