package com.niit.backend.dao;

import java.util.List;

import com.niit.backend.model.Addcart;



public interface AddcartDAO 
{

	public Boolean save (Addcart addcart);
	public List<Addcart>list();
	public Addcart get(String Id);
	
}
