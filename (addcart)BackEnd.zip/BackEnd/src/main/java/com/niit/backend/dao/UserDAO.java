package com.niit.backend.dao;

import java.util.List;


import com.niit.backend.model.User;

public interface UserDAO {
	public Boolean save(User user);
	public User get(String id);
	public List<User>list();

}
