/*package com.niit.backend.dao;

import java.util.List;

import com.niit.backend.model.Order;

public interface OrderDAO {
	
	
	
	
	public Boolean save(Order cart);
	
	public Boolean update (Order cart);
	
	public Boolean delete(Order cart);
	
	public Order get(String id);
	public List<Order>list();
	

}
*/